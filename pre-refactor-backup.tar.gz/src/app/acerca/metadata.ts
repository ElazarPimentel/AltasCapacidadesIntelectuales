import { acercaMetadata } from '@/lib/page-metadata/index';
export default acercaMetadata; 